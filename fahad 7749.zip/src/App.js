import './App.css';
import Home from './Pages/home/Home';
import Routing from './routing/Routing';
function App() {

  return (
    <div className="App">
<Routing />
    </div>
  );
}

export default App;
